using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=databasemusic;Integrated Security=True");
        con.Open();

        SqlCommand cmd = new SqlCommand("select * from songstable where id=1", con);
        SqlDataReader myReader = cmd.ExecuteReader();
        myReader.Read();
        con.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        if (Session["Authenticated"] != "true")
        {
            Response.Redirect("~/Login.aspx");
        }
        else
        {

            Response.ContentType = "audio/mp3";
            Response.AppendHeader("Content-Disposition", "attachment; filename=Jab We Met.mp3");
            Response.TransmitFile(Server.MapPath("./1.mp3"));
            Response.End();
        }

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (Session["Authenticated"] != "true")
        {
            Response.Redirect("~/Login.aspx");
        }
        else
        {
            Response.ContentType = "audio/mp3";
            Response.AppendHeader("Content-Disposition", "attachment; filename=Awaarapan.mp3");
            Response.TransmitFile(Server.MapPath("./2.mp3"));
            Response.End();
        }

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        if (Session["Authenticated"] != "true")
        {
            Response.Redirect("~/Login.aspx");
        }
        else
        {
            Response.ContentType = "audio/mp3";
            Response.AppendHeader("Content-Disposition", "attachment; filename=Bachna Ae Haseeno.mp3");
            Response.TransmitFile(Server.MapPath("./3.mp3"));
            Response.End();
        }


    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        if (Session["Authenticated"] != "true")
        {
            Response.Redirect("~/Login.aspx");
        }
        else
        {
            Response.ContentType = "audio/mp3";
            Response.AppendHeader("Content-Disposition", "attachment; filename=Yes Boss.mp3");
            Response.TransmitFile(Server.MapPath("./4.mp3"));
            Response.End();
        }

    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        if (Session["Authenticated"] != "true")
        {
            Response.Redirect("~/Login.aspx");
        }
        else
        {
            Response.ContentType = "audio/mp3";
            Response.AppendHeader("Content-Disposition", "attachment; filename=Saathiya.mp3");
            Response.TransmitFile(Server.MapPath("./5.mp3"));
            Response.End();
        }


    }
}
